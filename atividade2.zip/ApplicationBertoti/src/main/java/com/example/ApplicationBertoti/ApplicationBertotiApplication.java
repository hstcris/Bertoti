package com.example.ApplicationBertoti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationBertotiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationBertotiApplication.class, args);
	}

}
